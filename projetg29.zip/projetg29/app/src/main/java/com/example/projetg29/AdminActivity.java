package com.example.projetg29;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.LinkedList;

public class AdminActivity extends AppCompatActivity {
    Administrateur compte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // Définir les éléments du layout
        TextView textView = findViewById(R.id.textView5);
        Spinner dropdown = findViewById(R.id.dropDown_comptes);

        // Récuperer les informations de l'activité précédente
        Bundle extras = getIntent().getExtras();
        String username = extras.getString("user");
        String password = extras.getString("password");

        compte = new Administrateur(username, password);

        // Créer la liste d'éléments du dropdown
        LinkedList<String> comptesList;
        MyDBHandler dbHandler = new MyDBHandler(this);
        comptesList = dbHandler.getAllComptes();
        String[] comptes = new String[comptesList.size()/2];
        for(int i = 0; i < comptes.length; i++){
            String temp = comptesList.removeFirst();
            comptes[i] = temp+" ("+comptesList.removeFirst()+")";
        }

        // Créer un adapter pour le dropdown
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, comptes);
        dropdown.setAdapter(adapter);


        // Mettre à jour le texte
        textView.setText("Bienvenue "+compte.getUsername()+", vous êtes connecté en tant que Administrateur");
    }


}
