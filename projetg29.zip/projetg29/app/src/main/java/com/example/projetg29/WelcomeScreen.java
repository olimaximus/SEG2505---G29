package com.example.projetg29;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class WelcomeScreen extends AppCompatActivity {
    Compte compte;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);

        // Définir les éléments du layout
        TextView textView = findViewById(R.id.textView5);

        // Récuperer les informations de l'activité précédente
        Bundle extras = getIntent().getExtras();
        String username = extras.getString("user");
        String type = extras.getString("type");
        MyDBHandler dbHandler = new MyDBHandler(this);
        compte = dbHandler.findCompte(username);


        // Mettre à jour le texte
        textView.setText("Bienvenue "+username+", vous êtes connecté en tant que "+ type);






    }
}