package com.example.projetg29;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class WelcomeScreen extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);

        // Définir les éléments du layout
        TextView textView = findViewById(R.id.textView5);

        // Récuperer les informations de l'activité précédente
        Bundle extras = getIntent().getExtras();
        String username = extras.getString("username");
        String user_type = extras.getString("user_type");

        // Mettre à jour le texte
        textView.setText("Bienvenue "+username+", vous êtes connecté en tant que "+user_type);



    }
}