package com.example.projetg29;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Administrateur extends AppCompatActivity {

    private String username = "";
    private String password = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administrateur);
    }

    public Administrateur(String username, String password){
        this.username = username;
        this.password = password;
    }

    public String getUsername(){
        return username;
    }

    public String getPassword(){
        return password;
    }
}