package com.example.projetg29;

public class Compte {
    // Attributs
    private String username;
    private String password;

    // Constructeur
    public Compte(String username, String password){
        this.username = username;
        this.password = password;
    }

    public Compte(){

    }
    public String getType(){
        if(this instanceof Administrateur){
            return "Administrateur";
        }
        else if(this instanceof Employe){
            return "Employé";
        }
        else if(this instanceof Client){
            return "Client";
        }
        else{
            return "Compte";
        }
    }

    // Accesseurs et Modificateurs
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
