package com.example.projetg29;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RemplirServiceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remplir_service);
    }
}