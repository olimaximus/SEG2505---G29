package com.example.projetg29;

import android.database.sqlite.SQLiteOpenHelper;

public class DBServices  {
    private static final int DATABASE_VERSION = 3;
    private static final String DATABASE_NAME = "serviceDB.db";
    public static final String TABLE_SERVICES = "services";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_USERTYPE = "usertype";



}
